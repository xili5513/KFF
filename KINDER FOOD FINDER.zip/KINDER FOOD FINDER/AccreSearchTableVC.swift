//
//  AccraSearchTableVC.swift
//  KINDER FOOD FINDER
//
//  Created by heboning on 2019/03/28.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

import UIKit

class AccraSearchTableVC: UITableViewController , UISearchResultsUpdating{
    
    
    var Rawdatas: [Rawdata] = []
    var sc: UISearchController!
    var searchResults: [Rawdata] = []
    
    func searchFilter(text: String){
        searchResults = Rawdatas.filter({ (Rawdata) -> Bool in
            return Rawdata.FIELD3.localizedCaseInsensitiveContains(text)
        })
    }

    
    
    
    
    @IBAction func favBtnTap(_ sender: UIButton) {
        // two dimensinal coordinate system
        let btnPos = sender.convert(CGPoint.zero, to: self.tableView)
     //  print(btnPos)
        //order of data
        let indexPath = tableView.indexPathForRow(at: btnPos)!
        
     //  print(indexPath)
        self.Rawdatas[indexPath.row].FIELD6 = !self.Rawdatas[indexPath.row].FIELD6
 
        let cell = tableView.cellForRow(at: indexPath) as! CardCell
        
        cell.favorite = self.Rawdatas[indexPath.row].FIELD6
        
        
    }
    
    
    func loadJson() {
        let coder = JSONDecoder()
        
        do{
            let url = Bundle.main.url(forResource: "Rawdata", withExtension: "json")!
            let data = try Data(contentsOf: url)
            Rawdatas = try coder.decode([Rawdata].self, from: data)
        }
        catch{
            print("Failed load",error)
            
        }
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        if var text = searchController.searchBar.text{
            text = text.trimmingCharacters(in: .whitespaces)
            searchFilter(text: text)
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        loadJson()
    //Initialize the search box
        sc = UISearchController(searchResultsController: nil)
        sc.searchResultsUpdater = self
        tableView.tableHeaderView = sc.searchBar
        sc.dimsBackgroundDuringPresentation = false
        sc.searchBar.searchBarStyle = .minimal
        sc.searchBar.placeholder = "Search By Accreditation..."
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return sc.isActive ? searchResults.count : Rawdatas.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let id = String(describing: CardCell.self)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: id, for: indexPath) as! CardCell
        
        
        let Rawdata = sc.isActive ? searchResults[indexPath.row] : Rawdatas[indexPath.row]
        // Configure the cell...
        cell.classLabel.text  = Rawdata.FIELD1
        cell.accradLabel.text = Rawdata.FIELD3
        cell.brandLabel.text = Rawdata.FIELD4
        cell.backImageView.image = UIImage(named: Rawdata.FIELD1)
        cell.favorite = Rawdata.FIELD6
        
        //cell.accessoryType = Rawdata.FIELD6 ? .checkmark : .none
        return cell
    }
    
  
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return !sc.isActive
    }
    
    
    
}
