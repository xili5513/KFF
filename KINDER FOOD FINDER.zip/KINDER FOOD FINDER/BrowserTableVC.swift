//
//  BrowserTableVC.swift
//  KINDER FOOD FINDER
//
//  Created by heboning on 2019/03/29.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

import UIKit

class BrowserTableVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

      
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }

  
    
}
