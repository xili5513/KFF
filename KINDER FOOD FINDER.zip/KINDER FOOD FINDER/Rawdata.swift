//
//  Data.swift
//  KINDER FOOD FINDER
//
//  Created by heboning on 2019/03/28.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

struct Rawdata: Codable {
    var FIELD1 = ""
    var FIELD2 = ""
    var FIELD3 = ""
    var FIELD4 = ""
    var FIELD5 = ""
    var FIELD6 = false
    var FIELD7 = ""
    
}
